import { Switch, Route, Router } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import Welcome from "./pages/welcome";
import Mailbox from "./pages/mailbox";
import LetterPage from "./pages/letter";

function App() {
  return (
    <Router hook={useHashLocation}>
      <Switch>
        <Route path="/" component={Welcome} />
        <Route path="/mailbox" component={Mailbox} />
        <Route path="/letter/:id" component={LetterPage} />
        <Route>
          <div className="min-h-screen flex items-center justify-center" style={{ background: "#fce8f0" }}>
            <p style={{ fontFamily: "var(--app-font-serif)", color: "#8a4060" }}>Page not found.</p>
          </div>
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
