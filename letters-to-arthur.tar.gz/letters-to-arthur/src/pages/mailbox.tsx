import { useState } from "react";
import { useLocation } from "wouter";
import { letters } from "../data/letters";

const envelopeColors = [
  { bg: "#fce8f0", border: "#e8b0c8" },
  { bg: "#fef3e2", border: "#f0d090" },
  { bg: "#eef0f8", border: "#b0b8e0" },
  { bg: "#f0ede8", border: "#d0c0b0" },
  { bg: "#ece8f4", border: "#c0b0d8" },
  { bg: "#fce8f0", border: "#e8a8c0" },
  { bg: "#edf8ee", border: "#a0d0a8" },
  { bg: "#f8f0fe", border: "#c8a8e8" },
];

export default function Mailbox() {
  const [, setLocation] = useLocation();
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(160deg, #fce8f0 0%, #f8e8f4 50%, #ede4f8 100%)",
      }}
    >
      <div style={{ textAlign: "center", paddingTop: "3.5rem", paddingBottom: "1.5rem", paddingInline: "1.5rem" }}>
        <button
          onClick={() => setLocation("/")}
          style={{
            fontFamily: "var(--app-font-serif)",
            color: "#a06080",
            fontStyle: "italic",
            fontSize: "0.875rem",
            background: "none",
            border: "none",
            cursor: "pointer",
            marginBottom: "1.5rem",
            display: "inline-block",
            opacity: 0.85,
          }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = "0.6"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = "0.85"; }}
        >
          ← back
        </button>

        <h1
          style={{
            fontFamily: "var(--app-font-display)",
            fontSize: "clamp(2rem, 5vw, 3rem)",
            fontWeight: 500,
            fontStyle: "italic",
            color: "#4a1a2e",
            lineHeight: 1.2,
            marginBottom: "0.5rem",
          }}
        >
          Your Mailbox
        </h1>
        <p style={{ fontFamily: "var(--app-font-script)", fontSize: "1.15rem", color: "#b06080" }}>
          Pick the one you need right now
        </p>
      </div>

      <div
        style={{
          maxWidth: "52rem",
          margin: "0 auto",
          padding: "0 1.25rem 5rem",
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(min(100%, 22rem), 1fr))",
          gap: "1.25rem",
        }}
      >
        {letters.map((letter, i) => {
          const colors = envelopeColors[i % envelopeColors.length];
          const isHovered = hoveredId === letter.id;

          return (
            <button
              key={letter.id}
              onClick={() => setLocation(`/letter/${letter.id}`)}
              onMouseEnter={() => setHoveredId(letter.id)}
              onMouseLeave={() => setHoveredId(null)}
              className={`animate-fade-in stagger-${Math.min(i + 1, 8)}`}
              style={{
                animationFillMode: "forwards",
                opacity: 0,
                textAlign: "left",
                width: "100%",
                borderRadius: "1rem",
                overflow: "hidden",
                background: colors.bg,
                border: `1.5px solid ${colors.border}`,
                cursor: "pointer",
                transform: isHovered ? "translateY(-4px) scale(1.01)" : "translateY(0) scale(1)",
                transition: "transform 0.25s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.25s ease",
                boxShadow: isHovered
                  ? "0 12px 40px rgba(160,60,100,0.2), 0 2px 8px rgba(0,0,0,0.08)"
                  : "0 2px 12px rgba(0,0,0,0.07)",
              }}
            >
              {/* Envelope flap */}
              <div
                style={{
                  height: "56px",
                  background: `linear-gradient(135deg, ${colors.bg} 49%, ${colors.border} 50%)`,
                  borderBottom: `1.5px solid ${colors.border}`,
                  position: "relative",
                }}
              >
                <div
                  className="seal-pulse"
                  style={{
                    position: "absolute",
                    right: "1rem",
                    top: "50%",
                    transform: "translateY(-50%)",
                    width: "2rem",
                    height: "2rem",
                    borderRadius: "9999px",
                    background: letter.sealColor,
                    boxShadow: `0 2px 8px ${letter.sealColor}60`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "white",
                    fontFamily: "var(--app-font-display)",
                    fontStyle: "italic",
                    fontSize: "0.7rem",
                    fontWeight: 700,
                  }}
                >
                  C
                </div>
              </div>

              {/* Envelope body */}
              <div style={{ padding: "1.25rem 1.5rem" }}>
                <div
                  style={{
                    color: letter.ribbonColor,
                    fontFamily: "var(--app-font-serif)",
                    letterSpacing: "0.15em",
                    textTransform: "uppercase",
                    fontSize: "0.7rem",
                    marginBottom: "0.5rem",
                  }}
                >
                  for Arthur
                </div>
                <p
                  style={{
                    fontFamily: "var(--app-font-display)",
                    fontSize: "1.05rem",
                    fontWeight: 500,
                    fontStyle: "italic",
                    color: "#4a1a2e",
                    lineHeight: 1.35,
                  }}
                >
                  {letter.label}
                </p>
                <div
                  style={{
                    fontFamily: "var(--app-font-script)",
                    color: letter.ribbonColor,
                    fontSize: "0.9rem",
                    marginTop: "0.75rem",
                  }}
                >
                  — from Cindy, with love ♡
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <div style={{ textAlign: "center", paddingBottom: "2.5rem" }}>
        <p style={{ fontFamily: "var(--app-font-script)", fontSize: "1.1rem", color: "#c080a0" }}>
          more letters on the way ♡
        </p>
      </div>
    </div>
  );
}
