import { useEffect, useState } from "react";
import { useLocation } from "wouter";

const petals = Array.from({ length: 12 }, (_, i) => ({
  id: i,
  left: `${(i * 8.5) % 100}%`,
  delay: `${(i * 0.7) % 8}s`,
  duration: `${7 + (i % 5)}s`,
  symbol: ["✿", "❀", "✾", "❁"][i % 4],
  color: ["#d4789a", "#c86090", "#b87ab8", "#e098b0"][i % 4],
}));

export default function Welcome() {
  const [, setLocation] = useLocation();
  const [visible, setVisible] = useState(false);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  function handleEnter() {
    setLeaving(true);
    setTimeout(() => setLocation("/mailbox"), 600);
  }

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden"
      style={{
        background: "linear-gradient(160deg, #fce8f0 0%, #f5e0ef 40%, #ede0f8 100%)",
        opacity: leaving ? 0 : 1,
        transition: "opacity 0.6s ease",
      }}
    >
      {petals.map((p) => (
        <span
          key={p.id}
          className="petal"
          style={{
            left: p.left,
            animationDelay: p.delay,
            animationDuration: p.duration,
            color: p.color,
            opacity: 0.45,
            fontSize: "1.2rem",
          }}
        >
          {p.symbol}
        </span>
      ))}

      <div
        className="relative z-10 text-center px-8 py-12 max-w-lg mx-auto"
        style={{
          opacity: visible ? 1 : 0,
          transform: visible ? "translateY(0)" : "translateY(24px)",
          transition: "all 0.9s cubic-bezier(0.34, 1.26, 0.64, 1)",
        }}
      >
        <div
          className="mx-auto mb-8 w-20 h-20 rounded-full flex items-center justify-center text-3xl"
          style={{
            background: "linear-gradient(135deg, #e8789a, #b850a0)",
            boxShadow: "0 8px 32px rgba(180, 80, 120, 0.3)",
          }}
        >
          ✉
        </div>

        <p
          style={{
            fontFamily: "var(--app-font-serif)",
            color: "#c06080",
            letterSpacing: "0.2em",
            textTransform: "uppercase",
            fontSize: "0.75rem",
            marginBottom: "0.75rem",
          }}
        >
          a letter collection
        </p>

        <h1
          style={{
            fontFamily: "var(--app-font-display)",
            fontSize: "clamp(2.4rem, 6vw, 3.6rem)",
            fontWeight: 500,
            color: "#4a1a2e",
            fontStyle: "italic",
            lineHeight: 1.2,
            marginBottom: "0.5rem",
          }}
        >
          Letters to Arthur
        </h1>

        <p
          style={{
            fontFamily: "var(--app-font-script)",
            fontSize: "1.3rem",
            color: "#b06080",
            marginBottom: "2.5rem",
          }}
        >
          — from your Cindy
        </p>

        <p
          style={{
            fontFamily: "var(--app-font-serif)",
            color: "#6a3050",
            fontStyle: "italic",
            lineHeight: 1.7,
            marginBottom: "2.5rem",
          }}
        >
          A little mailbox, just for you.<br />
          Open a letter whenever you need one.
        </p>

        <button
          onClick={handleEnter}
          style={{
            fontFamily: "var(--app-font-serif)",
            fontSize: "1rem",
            background: "linear-gradient(135deg, #c2516b, #a03870)",
            boxShadow: "0 4px 24px rgba(180, 60, 100, 0.35)",
            letterSpacing: "0.05em",
            padding: "1rem 2.5rem",
            borderRadius: "9999px",
            color: "white",
            border: "none",
            cursor: "pointer",
            transition: "transform 0.2s ease, box-shadow 0.2s ease",
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-2px)";
            (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 8px 32px rgba(180, 60, 100, 0.45)";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLButtonElement).style.transform = "translateY(0)";
            (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 4px 24px rgba(180, 60, 100, 0.35)";
          }}
        >
          Open your mailbox
        </button>

        <p
          style={{
            fontFamily: "var(--app-font-script)",
            fontSize: "1.1rem",
            color: "#b08898",
            marginTop: "2rem",
          }}
        >
          with all my love ♡
        </p>
      </div>

      <div style={{ position: "absolute", top: "1.5rem", left: "2rem", fontSize: "2.5rem", color: "rgba(200,100,140,0.2)", transform: "rotate(-20deg)", userSelect: "none" }}>❧</div>
      <div style={{ position: "absolute", bottom: "1.5rem", right: "2rem", fontSize: "2.5rem", color: "rgba(160,80,160,0.2)", transform: "rotate(20deg) scaleX(-1)", userSelect: "none" }}>❧</div>
    </div>
  );
}
