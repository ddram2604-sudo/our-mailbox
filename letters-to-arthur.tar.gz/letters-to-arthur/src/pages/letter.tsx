import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { letters } from "../data/letters";

export default function LetterPage() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const [phase, setPhase] = useState<"envelope" | "opening" | "letter">("envelope");

  const letter = letters.find((l) => l.id === id);

  useEffect(() => { setPhase("envelope"); }, [id]);

  if (!letter) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#fce8f0" }}>
        <div style={{ textAlign: "center" }}>
          <p style={{ fontFamily: "var(--app-font-serif)", color: "#8a4060" }}>Letter not found.</p>
          <button onClick={() => setLocation("/mailbox")} style={{ marginTop: "1rem", color: "#c2516b", fontFamily: "var(--app-font-serif)", background: "none", border: "none", cursor: "pointer", textDecoration: "underline" }}>
            Back to mailbox
          </button>
        </div>
      </div>
    );
  }

  function openEnvelope() {
    setPhase("opening");
    setTimeout(() => setPhase("letter"), 600);
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "2.5rem 1.25rem 5rem",
        background: `linear-gradient(160deg, ${letter.color} 0%, #f8e8f4 60%, #ede4f8 100%)`,
      }}
    >
      <button
        onClick={() => setLocation("/mailbox")}
        style={{
          alignSelf: "flex-start",
          fontFamily: "var(--app-font-serif)",
          color: "#a06080",
          fontStyle: "italic",
          fontSize: "0.875rem",
          background: "none",
          border: "none",
          cursor: "pointer",
          marginBottom: "2rem",
          opacity: 0.85,
        }}
        onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = "0.6"; }}
        onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = "0.85"; }}
      >
        ← back to mailbox
      </button>

      {/* Envelope stage */}
      {(phase === "envelope" || phase === "opening") && (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            opacity: phase === "opening" ? 0 : 1,
            transform: phase === "opening" ? "translateY(20px) scale(0.95)" : "translateY(0) scale(1)",
            transition: "all 0.5s ease-in",
          }}
        >
          <div
            className="animate-float"
            onClick={openEnvelope}
            style={{
              width: "min(340px, 85vw)",
              background: letter.color,
              border: `2px solid ${letter.ribbonColor}40`,
              boxShadow: "0 16px 48px rgba(160,60,100,0.2)",
              borderRadius: "1rem",
              overflow: "hidden",
              cursor: "pointer",
              position: "relative",
            }}
          >
            {/* Flap */}
            <div
              style={{
                height: "90px",
                background: `linear-gradient(145deg, ${letter.color} 48%, ${letter.ribbonColor}50 50%)`,
                borderBottom: `1.5px solid ${letter.ribbonColor}60`,
              }}
            />

            {/* Wax seal */}
            <div
              className="seal-pulse"
              style={{
                position: "absolute",
                top: "3.5rem",
                left: "50%",
                transform: "translateX(-50%)",
                width: "4rem",
                height: "4rem",
                borderRadius: "9999px",
                background: `radial-gradient(circle at 35% 35%, ${letter.sealColor}cc, ${letter.sealColor})`,
                boxShadow: `0 4px 16px ${letter.sealColor}60`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
                fontFamily: "var(--app-font-display)",
                fontStyle: "italic",
                fontSize: "1.25rem",
                fontWeight: 700,
                zIndex: 10,
              }}
            >
              C
            </div>

            {/* Body */}
            <div style={{ padding: "3rem 2rem 2rem", textAlign: "center" }}>
              <div style={{ color: letter.ribbonColor, fontFamily: "var(--app-font-serif)", letterSpacing: "0.2em", textTransform: "uppercase", fontSize: "0.7rem", marginBottom: "0.5rem" }}>
                for Arthur
              </div>
              <p style={{ fontFamily: "var(--app-font-display)", fontSize: "1.1rem", fontWeight: 500, fontStyle: "italic", color: "#4a1a2e", lineHeight: 1.35 }}>
                {letter.label}
              </p>
              <div style={{ fontFamily: "var(--app-font-script)", color: letter.sealColor, fontSize: "1rem", marginTop: "1rem" }}>
                — from your Cindy
              </div>
            </div>
          </div>

          <button
            onClick={openEnvelope}
            style={{
              marginTop: "2rem",
              padding: "0.75rem 2rem",
              borderRadius: "9999px",
              color: "white",
              fontFamily: "var(--app-font-serif)",
              fontSize: "0.95rem",
              background: `linear-gradient(135deg, ${letter.sealColor}, ${letter.sealColor}cc)`,
              boxShadow: `0 4px 20px ${letter.sealColor}50`,
              letterSpacing: "0.04em",
              border: "none",
              cursor: "pointer",
              transition: "transform 0.2s ease",
            }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-2px)"; }}
            onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.transform = "translateY(0)"; }}
          >
            Open this letter
          </button>

          <p style={{ fontFamily: "var(--app-font-script)", color: "#b08898", fontSize: "1rem", marginTop: "1rem" }}>
            tap to unseal ♡
          </p>
        </div>
      )}

      {/* Letter stage */}
      {phase === "letter" && (
        <div className="animate-letter-rise" style={{ width: "100%", maxWidth: "38rem", animationFillMode: "forwards" }}>
          <div
            className="paper"
            style={{
              borderRadius: "1rem",
              padding: "2.5rem 2rem",
              position: "relative",
              boxShadow: "0 8px 40px rgba(0,0,0,0.10), 0 2px 8px rgba(0,0,0,0.06)",
              border: `1px solid ${letter.ribbonColor}30`,
            }}
          >
            <div style={{ position: "absolute", top: 0, right: 0, width: "4rem", height: "4rem", borderBottomLeftRadius: "9999px", background: `${letter.ribbonColor}18` }} />

            <div style={{ textAlign: "right", fontSize: "0.75rem", fontFamily: "var(--app-font-serif)", color: "#b09090", fontStyle: "italic", marginBottom: "1.5rem" }}>
              written with love ♡
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
              {letter.content.map((paragraph, i) => {
                const isGreeting = i === 0;
                const isSignoff = i >= letter.content.length - 2;
                return (
                  <p
                    key={i}
                    className={`animate-fade-in stagger-${Math.min(i + 1, 8)}`}
                    style={{
                      fontFamily: isGreeting || isSignoff ? "var(--app-font-display)" : "var(--app-font-serif)",
                      fontSize: isGreeting ? "1.15rem" : "1rem",
                      fontStyle: isGreeting || isSignoff ? "italic" : "normal",
                      lineHeight: 1.85,
                      color: isSignoff ? "#7a3050" : "#3a1828",
                      fontWeight: isSignoff ? 500 : 400,
                      opacity: 0,
                      animationFillMode: "forwards",
                    }}
                  >
                    {paragraph}
                  </p>
                );
              })}

              {letter.ps && (
                <p
                  className="animate-fade-in"
                  style={{
                    fontFamily: "var(--app-font-serif)",
                    fontSize: "0.9rem",
                    fontStyle: "italic",
                    color: "#a07080",
                    borderTop: `1px solid ${letter.ribbonColor}40`,
                    paddingTop: "1rem",
                    marginTop: "0.5rem",
                    opacity: 0,
                    animationDelay: "0.65s",
                    animationFillMode: "forwards",
                    lineHeight: 1.7,
                  }}
                >
                  {letter.ps}
                </p>
              )}
            </div>

            <div style={{ textAlign: "right", fontFamily: "var(--app-font-script)", fontSize: "1.6rem", color: letter.sealColor, marginTop: "2rem" }}>
              Cindy ♡
            </div>
          </div>

          <div style={{ display: "flex", gap: "0.75rem", marginTop: "1.5rem", justifyContent: "center", flexWrap: "wrap" }}>
            <button
              onClick={() => setPhase("envelope")}
              style={{
                padding: "0.625rem 1.25rem",
                borderRadius: "9999px",
                fontSize: "0.875rem",
                fontFamily: "var(--app-font-serif)",
                color: "#a06070",
                border: `1px solid ${letter.ribbonColor}60`,
                background: "white",
                fontStyle: "italic",
                cursor: "pointer",
                transition: "opacity 0.2s",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = "0.7"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = "1"; }}
            >
              close letter
            </button>
            <button
              onClick={() => setLocation("/mailbox")}
              style={{
                padding: "0.625rem 1.25rem",
                borderRadius: "9999px",
                fontSize: "0.875rem",
                fontFamily: "var(--app-font-serif)",
                color: "white",
                border: "none",
                background: `linear-gradient(135deg, ${letter.sealColor}, ${letter.sealColor}cc)`,
                fontStyle: "italic",
                cursor: "pointer",
                transition: "transform 0.2s ease",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-1px)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.transform = "translateY(0)"; }}
            >
              back to mailbox
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
