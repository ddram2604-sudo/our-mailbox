# Letters to Arthur

A personal interactive mailbox website — from Cindy, with love.

## How to edit your letters

Open `src/data/letters.ts` — each letter has:
- `label` — the envelope text (e.g. "Open when you miss me")
- `content` — an array of paragraphs (each item is one paragraph)
- `ps` — an optional postscript line
- `color`, `sealColor`, `ribbonColor` — the envelope colors (hex codes)

To add a new letter, copy an existing one, give it a new unique `id`, and add it to the array.

## How to deploy to GitHub Pages

### First time setup

1. Create a new repository on GitHub (can be private or public)
2. Upload all these files to the repo (drag & drop or git push)
3. Go to your repo → **Settings** → **Pages**
4. Under **Source**, select **GitHub Actions**
5. Push to the `main` branch — it will build and deploy automatically

Your site will be live at:
`https://your-username.github.io/your-repo-name/`

### After that

Every time you push a change to `main`, it automatically rebuilds and deploys.

## Running locally (optional)

```bash
npm install
npm run dev
```
